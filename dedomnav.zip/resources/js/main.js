

$(document).ready(function(){
    $("#hide").click(function(){
      $("#left_section").addClass("left-hide");
      $("#right_section").addClass("w-100");
      $("#left_contianer").removeClass("left-section-container");
      $("#hide1").fadeIn(3000);
     
    });
    $("#hide1").click(function(){
      $("#left_section").removeClass("left-hide");
      $("#right_section").removeClass("w-100");
      $("#left_contianer").addClass("left-section-container");
      $("#hide1").fadeOut("fast");
     
    });
  });




function myFunction(x) {
  if (x.matches) { // If media query matches
    document.getElementById("left_section").style.display = "none";
    document.getElementById("right_section").classList.add("w-100");
    document.getElementById("top_nav").style.display = "block";

  } else {
    document.getElementById("left_section").style.display = "block";
    document.getElementById("top_nav").style.display = "none";


  }
}

var x = window.matchMedia("(max-width: 990px)")
myFunction(x) // Call listener function at run time
x.addListener(myFunction) // Attach listener function on state changes
